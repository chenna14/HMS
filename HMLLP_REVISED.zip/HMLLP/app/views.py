from django.shortcuts import render
from django.http import HttpResponse
import random
from app.models import prescribes,procedure,patient,physician,fdo,dba,appointment,count,completed,admitted,stay,room,patients,deo,tested_patient,treatments
from app.forms import PatientForm
from django.shortcuts import render, redirect
from datetime import datetime
from datetime import timedelta
from django.utils import timezone
from PIL import Image
from io import BytesIO
from django.db.models import Max
from django.core.files.uploadedfile import InMemoryUploadedFile
from django.conf import settings
from django.core.mail import EmailMessage
from django.shortcuts import get_object_or_404
# import User from django
from django.contrib.auth.models import User
from django.contrib.auth import login ,logout , authenticate
from django.contrib.auth.decorators import login_required
# Create your views here.







# def say_hello(request):
#     #return HttpResponse('Hello world')
#     results=procedure.objects.all()
#     print("1")
#     print(results)
#     return render(request, 'hello.html', {"data": results})
#     #return render(request,'hello.html',("data":results))

def index(request):
    return render(request, 'Login.html')

def home(request):
    return render(request,'Home.html')

# def Login(request):
#     global user
#     user = int(request.POST.get('user'))
#     pasw = request.POST.get('pasw')
#     print("1")
#     # Handle the case where no matching physician is found
#     try:
#         dr = physician.objects.get(employeeid=user, password=pasw)
#         result = appointment.objects.filter(physicianid = user)
#         user1 = authenticate(request,username = user , password = pasw)
#         if user1:
#             login(request,user1)
#             return render(request,'Doctor.html',{"data":result})
#     # Process the physician object

#     except physician.DoesNotExist:
#         try:
#             dr = fdo.objects.get(id=user, password=pasw)
#             user1 = authenticate(request,username = user , password = pasw)
#             if user1:
#                 login(request,user1)
#                 return render(request,'FDO.html')
#             # result = patient.objects.get(pcp = user)    
#     # Process the physician object
#         except fdo.DoesNotExist:
#             try:
#                 dr = dba.objects.get(id=user, password=pasw)
#                 return render(request,'DBA.html')
                
#             # result = patient.objects.get(pcp = user) 
#     # Process the physician object

#             except dba.DoesNotExist:
#                 try:
#                     results = tested_patient.objects.all()
#                     user1 = authenticate(request,username = user , password = pasw)
#                     if user1:
#                         login(request,user1)
#                         return render(request,'DEO.html',{'data':results})
                
#             # result = patient.objects.get(pcp = user) 
#     # Process the physician object

#                 except dba.DoesNotExist:
#                     return render(request,'Login.html',{"error":'Invalid userid or password'})


def Login(request):
    global user
    user = int(request.POST.get('user'))
    pasw = request.POST.get('pasw')
  
    print("1")
    # Handle the case where no matching physician is found
    try:
        dr = physician.objects.get(employeeid=user, password=pasw)
        result = appointment.objects.filter(physicianid = user)
        return render(request,'Doctor.html',{"data":result})
    # Process the physician object

    except physician.DoesNotExist:
        try:
            dr = fdo.objects.get(id=user, password=pasw)
            # result = patient.objects.get(pcp = user)
            return render(request,'FDO.html')
    # Process the physician object

        except fdo.DoesNotExist:
            try:
                dr = dba.objects.get(id=user, password=pasw)
                return render(request,'DBA.html')
                
            # result = patient.objects.get(pcp = user) 
    # Process the physician object

            except dba.DoesNotExist:
                try:
                    results = tested_patient.objects.all()
                    dr = deo.objects.get(id=user, pasw=pasw)
                    return render(request,'DEO.html',{'data':results})
                
            # result = patient.objects.get(pcp = user) 
    # Process the physician object

                except dba.DoesNotExist:
                    return render(request,'Login.html',{"error":'Invalid userid or password'})




def queryp(request):
    id = request.GET["patient"]
    ID = int(id)
    k=1
    C = count.objects.get(id=k)
    if(ID>C.countp or ID<1):
        result = appointment.objects.filter(physicianid = user)
        return render(request,'Doctor.html',{"data":result,"error":'enter valid patient id'})
    results=patient.objects.get(ssn = id)
    print(results)
    presc = prescribes.objects.filter(patientid=id)
    treat = treatments.objects.filter(patient_id=id)
    return render(request, 'queryp.html', {"data": results,"P":presc,"T":treat})

# def add_patient(request):
#     if request.method == 'POST':
#         form = PatientForm(request.POST)
#         if form.is_valid():
#             physician_id = form.cleaned_data['pcp']
#             phy = physician.objects.get(employeeid=physician_id.employeeid)
#             pa = patient(
#                 ssn=form.cleaned_data['ssn'],
#                 name=form.cleaned_data['name'],
#                 age=form.cleaned_data['age'],
#                 gender=form.cleaned_data['gender'],
#                 pcp=phy
#             )
#             pa.save()
#             return render(request, 'success.html')
#     else:
#         form = PatientForm()
#     return render(request, 'add_patient.html', {'form': form})



def add_procedure(request):
    # person = procedure(name='John Doe', code=25,cost = 1000)
    # person.save()
    user = User.objects.all()
    for u in user:
        print(u)
    return render(request,'success.html')
    
# def add_patient(request):
#     if request.method == 'POST':
#         form = PatientForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('patient_list')
#     else:
#         form = PatientForm()
#     return render(request, 'add_patient.html', {'form': form})


def add_front_desk_operator(request):
    if request.method == 'POST':
        k = 1
        c = count.objects.get(id = k)
        c.countfdo = c.countfdo + 1
        physician_instance = fdo(
            id = c.countfdo,
            password = request.POST['password'],
            name = request.POST['name'],
            mail=request.POST['email']
        )
        id1 = 'userid = ' + str(physician_instance.id) + 'and password = ' + physician_instance.password
        message = 'The user details are: {}'.format(id1)
        email = EmailMessage(
        'User details',
        message,
        settings.EMAIL_HOST_USER,
        [physician_instance.mail],
        # reply_to=['another@example.com'],
        headers={'Message-ID': 'foo'},
        )
        email.send()
        physician_instance.save()
        c.save()
        return render(request, 'DBA.html')
        # return redirect('add_doctor')
    else:
        return render(request, 'add_front_desk_operator.html')


# def add_front_desk_operator(request):
#     return render(request, 'add_front_desk_operator.html')


def add_data_entry_operators(request):
    if request.method == 'POST':
        k = 1
        c = count.objects.get(id = k)
        c.countdeo = c.countdeo - 1
        physician_instance = deo(
            id = c.countdeo,
            pasw = request.POST['password'],
            name = request.POST['name'],
            mail=request.POST['email']
        )
        id1 = 'userid = ' + str(physician_instance.id) + 'and password = ' + physician_instance.pasw
        message = 'The user details are: {}'.format(id1)
        email = EmailMessage(
        'User details',
        message,
        settings.EMAIL_HOST_USER,
        [physician_instance.mail],
        # reply_to=['another@example.com'],
        headers={'Message-ID': 'foo'},
        )
        email.send()
        physician_instance.save()
        c.save()
        return render(request, 'DBA.html')
        # return redirect('add_doctor')
    else:
        return render(request, 'add_data_entry_operators.html')


def delete_front_desk_operator(request):
    doctors = fdo.objects.all()
    return render(request, 'delete_front_desk_operator.html', {'doctors': doctors})

def confirm_delete_front_desk_operator(request):
    if request.method == 'POST':
        doctor_id = request.POST.get('doctor_id')
        phys = fdo.objects.get(id=doctor_id)
        email = EmailMessage(
         'Deletion of user',
          'your user is deleyed',
          settings.EMAIL_HOST_USER,
          [phys.mail],
        # reply_to=['another@example.com'],
           headers={'Message-ID': 'foo'},
        )
        email.send()
        phys.delete()
        return render(request, 'DBA.html')


def delete_data_entry_operators(request):
    doctors = deo.objects.all()
    return render(request, 'delete_data_entry_operators.html',{'doctors': doctors})

def confirm_delete_data_entry_operator(request):
    if request.method == 'POST':
        doctor_id = request.POST.get('doctor_id')
        phys = deo.objects.get(id=doctor_id)
        email = EmailMessage(
         'Deletion of user',
          'your user is deleyed',
          settings.EMAIL_HOST_USER,
          [phys.mail],
        # reply_to=['another@example.com'],
           headers={'Message-ID': 'foo'},
        )
        email.send()
        phys.delete()
        return render(request, 'DBA.html')



def add_doctor(request):
    if request.method == 'POST':
        k =1 
        c = count.objects.get(id = k)
        c.countu = c.countu + 1
        physician_instance = physician(
            employeeid = c.countu,
            name = request.POST['name'],
            password = request.POST['password'],
            department = request.POST['department'],
            mail=request.POST['email']
        )

        id1 = 'userid = ' + str(physician_instance.employeeid) + 'and password = ' + physician_instance.password
        message = 'The user details are: {}'.format(id1)
        email = EmailMessage(
        'User details',
        message,
        settings.EMAIL_HOST_USER,
        [physician_instance.mail],
        # reply_to=['another@example.com'],
        headers={'Message-ID': 'foo'},
        )
        email.send()
        physician_instance.save()
        c.save()
        return render(request, 'DBA.html')
        # return redirect('add_doctor')
    else:
        return render(request, 'add_doctor.html')


def delete_doctor(request):
    doctors = physician.objects.all()
    return render(request, 'delete_doctor.html', {'doctors': doctors})

def confirm_delete_doctor(request):
    if request.method == 'POST':
        doctor_id = request.POST.get('doctor_id')
        phys = physician.objects.get(employeeid=doctor_id)
        email = EmailMessage(
         'Deletion of user',
          'your user is deleyed',
          settings.EMAIL_HOST_USER,
          [phys.mail],
        # reply_to=['another@example.com'],
           headers={'Message-ID': 'foo'},
        )
        email.send()
        phys.delete()
        doctors = physician.objects.all()
    return render(request, 'delete_doctor.html', {'doctors': doctors})



def reg_patient(request):
    
    return render(request,'reg_patient.html')


def schedule(request):
    print(200)
    global de
    de = request.GET["dep"]
    global na
    na = request.GET["name"]
    global ag
    ag = request.GET["age"]
    global ge
    ge = request.GET["gender"]
    
    print(de)
    print(100)
    physicians = physician.objects.filter(department=de).values('employeeid', 'name')
    physician_ids = [physician['employeeid'] for physician in physicians]
    appointments = appointment.objects.filter(physicianid__in=physician_ids).order_by('-endtime')
    physician_data = []
    for phys in physicians:
        physician_endtime = appointments.filter(physicianid=phys['employeeid']).first().endtime if appointments.filter(physicianid=phys['employeeid']).exists() else None
        print(physician_endtime)
        physician_dict = {
            'id': phys['employeeid'],
            'name': phys['name'],
            'endtime': physician_endtime
        }
        physician_data.append(physician_dict)

    return render(request,'xyz.html',{'data':physician_data})

def schedule_appointment(request):
    physicianid = int(request.GET["doctor_name"])
    startdate = request.GET["appointment_date"]
    starttime = request.GET["appointment_time"]
    dt_str = startdate + ' ' + starttime

# Use strptime() to convert the string representation of the datetime to a datetime object
    dt = datetime.strptime(dt_str, '%Y-%m-%d %H:%M')
    dt_plus_30 = dt + timedelta(minutes=30)
    i = 1
    C = count.objects.get(id = i)
    C.counta = C.counta + 1
    C.countp = C.countp + 1
    P = patient(C.countp,na,ge,ag,physicianid)
    P.save()
    P = patients(C.countp,na,ge,ag,physicianid)
    P.save()
    A = appointment(C.counta,dt,dt_plus_30,physicianid,C.countp )
    A.save()
    C.save()
    return render(request,"FDO.html")


def past_records(request):
    dr = physician.objects.get(employeeid=user)
    result = completed.objects.filter(physicianid = user)
    return render(request,'past_records.html',{"data":result})


def back_doc(request):
    result = appointment.objects.filter(physicianid = user)
    return render(request,'Doctor.html',{"data":result})

def finish(request):
    result_id = request.POST.get('result_id')
    # print(result_id)
    C = appointment.objects.get(id = result_id)
    D = completed(
        id = C.id,
        starttime = C.starttime,
        endtime = C.endtime,
        physicianid = C.physicianid,
        patientid = C.patientid
    )
    D.save()
    E = admitted(
        id = C.id,
        starttime = C.starttime,
        endtime = C.endtime,
        physicianid = C.physicianid,
        patientid = C.patientid
    )
    E.save()
    C.delete()
 
    result = appointment.objects.filter(physicianid = user)
    return render(request,'Doctor.html',{"data":result})
    # Do something with the result_id value here

def admit_patient(request):
    result = admitted.objects.all()
    return render(request,'completed_patients.html',{"data":result})

def not_admit(request):
    result_id = request.POST.get('result_id')
    C = admitted.objects.get(id = result_id)
    C.delete()
    result = admitted.objects.all()
    return render(request,'completed_patients.html',{"data":result})

def admit(request):
    result_id = request.POST.get('result_id')
    C = admitted.objects.get(id = result_id)
    global pcr
    pcr = C.patientid
    arr = ['a'] * 20
    S = stay.objects.all()
    for room in S:
        arr[room.roomno.no-1]='u'
    C.save()
    return render(request,'room.html',{'data':arr})

def give_room(request):
    
    selected_room = request.POST.get('room')
    print(selected_room)
    selected_room_object = room.objects.get(no=selected_room)
    i = 1
    C = count.objects.get(id = i)
    C.countr = C.countr + 1
    St = stay(
        stayid = C.countr,
        roomno = selected_room_object,
        patientid = pcr
    )
    St.save()
    C.save()
    C = admitted.objects.get(patientid = pcr)
    C.delete()
    return render(request,'FDO.html')



def discharge_patient(request):
    result = stay.objects.all()
    return render(request,'discharge_patient.html',{'data':result})

def discharge(request):
    result_id = request.POST.get('result_id')
    sta = stay.objects.get(stayid = result_id)
    sta.delete()
    result = stay.objects.all()
    return render(request,'discharge_patient.html',{'data':result})
    
def testing_patient(request):
    result = patients.objects.all()
    return render(request,'testing_patient.html',{'data': result})

def tested(request):
    result_id = request.POST.get('result_id')
    sta = patients.objects.get(ssn = result_id)
    p = tested_patient(
        ssn = sta.ssn,
        name = sta.name,
    )
    p.save()
    sta.delete()
    result = patients.objects.all()
    return render(request,'testing_patient.html',{'data': result})

def Enter_details(request):
    return render(request,'results.html')

def record_treatment(request):
    # B.delete()
    if request.method == 'POST':
        patient_id = request.POST.get('patient_id')
        patient_name = request.POST.get('patient_name')
        patient_age = request.POST.get('patient_age')
        patient_gender = request.POST.get('patient_gender')
        symptoms = request.POST.get('symptoms')
        diagnosis = request.POST.get('diagnosis')
        treatment = request.POST.get('treatment')
        test_results = request.POST.get('test_results')
        image_file = request.FILES.get('x_ray')
        priority = request.POST.get('priority')
        m = 1
        C = count.objects.get(id = m)
        C.countT = C.countT + 1
        STR = 'image'+str(C.countT)+'.jpg'
        if image_file:
        # Convert the file data to bytes
           image_data = BytesIO(image_file.read())
        # Create an InMemoryUploadedFile instance
           uploaded_file = InMemoryUploadedFile(image_data, None, STR, 'image/jpeg', image_data.tell(), None)
           print('Image data:', uploaded_file)
        else:
            print('abhi')
            uploaded_file = None
        
        # Save the data to the model
        treatment_obj = treatments(
            treatment_id = C.countT,
            patient_id=patient_id,
            patient_name=patient_name,
            symptoms=symptoms,
            treatments=treatment,
            test_results=test_results,
            image=uploaded_file
        )
        if priority == 'urgent':
            id1 = patient.objects.get(ssn = treatment_obj.patient_id)
            id2 = physician.objects.get(employeeid = id1.pcp.employeeid)
            s = 'patient_id : ' + str(treatment_obj.patient_id) + ' ' + 'symptoms :' + treatment_obj.symptoms + ' ' + 'treatments :' + treatment_obj.treatments + ' ' + 'test_results :'+ treatment_obj.test_results
            message = 'The user details are: {}'.format(s)
            email = EmailMessage(
            'User details',
            message,
            settings.EMAIL_HOST_USER,
            [id2.mail],
            # reply_to=['another@example.com'],
            headers={'Message-ID': 'foo'},
            )
            email.send()
        treatment_obj.save()
        C.save()
        print('Saved treatment:', treatment_obj)
        B = tested_patient.objects.get(ssn = patient_id)
        B.delete()
        result = tested_patient.objects.all()
        return render(request,'DEO.html',{'data':result})

def prescriptions(request):
    id = int(request.GET["patient_name"])
    Dose = request.GET["prescriptions"]
    physician_id = user
    spatient = patient.objects.get(ssn=id)
    sphysician = physician.objects.get(employeeid = user)
    m = 1
    C = count.objects.get(id = m)
    C.countpr = C.countpr + 1
    D = prescribes(
        id = C.countpr,
        dose = Dose,
        physicianid = sphysician,
        patientid = spatient

    )
    C.save()
    D.save()
    result = appointment.objects.filter(physicianid = user)
    return render(request,'Doctor.html',{"data":result})

def past_treatments(request):
    result = treatments.objects.all()
    return render(request,'past_treatments.html',{"data":result})

def view_xray(request):
    id = request.POST.get('result_id')
    print(id)
    T =  treatments.objects.get(treatment_id=id)
    response = HttpResponse(content_type='image/jpeg')
    response.write(T.image.read())
    return response

def past_prescriptions(request):
    result = prescribes.objects.filter(physicianid=user)
    
    return render(request,'prescriptions.html',{"data":result})

def back_to_fdo(request):
    return render(request,'FDO.html')

def back_deo(request):
    results = tested_patient.objects.all()
    return render(request,'DEO.html',{'data':results})

def back_dba(request):
    return render(request,'DBA.html')



def send_email(request):
    print(settings.EMAIL_HOST_USER)
    email = EmailMessage(
        'Subject',
        'Hiiii',
        settings.EMAIL_HOST_USER,
        ['abhishekragala@gmail.com'],
        # reply_to=['another@example.com'],
        headers={'Message-ID': 'foo'},
    )
    email.send()
    return render(request, 'success.html')

def logout_(request):
    logout(request)
    return redirect ('home')


def urgent(request):
    if request.method == 'POST':
        print(100000)
        patient_id = request.POST.get('patient_id')
        print(patient_id)
        print(20)
        patient_name = request.POST.get('patient_name')
        patient_age = request.POST.get('patient_age')
        patient_gender = request.POST.get('patient_gender')
        symptoms = request.POST.get('symptoms')
        diagnosis = request.POST.get('diagnosis')
        treatment = request.POST.get('treatment')
        test_results = request.POST.get('test_results')
        image_file = request.FILES.get('x_ray')
        m = 1
        C = count.objects.get(id = m)
        C.countT = C.countT + 1
        STR = 'image'+str(C.countT)+'.jpg'
        if image_file:
        # Convert the file data to bytes
           image_data = BytesIO(image_file.read())
        # Create an InMemoryUploadedFile instance
           uploaded_file = InMemoryUploadedFile(image_data, None, STR, 'image/jpeg', image_data.tell(), None)
          
        else:
            
            uploaded_file = None
        
        # Save the data to the model
        treatment_obj = treatments(
            treatment_id = C.countT,
            patient_id=patient_id,
            patient_name=patient_name,
            symptoms=symptoms,
            treatments=treatment,
            test_results=test_results,
            image=uploaded_file
        )
        print(treatment_obj.patient_id)
        id1 = patient.objects.get(ssn = treatment_obj.patient_id)
        id2 = physician.objects.get(employeeid = id1.pcp)
        
        message = 'The user details are: {}'.format(treatment_obj)
        email = EmailMessage(
        'User details',
        message,
        settings.EMAIL_HOST_USER,
        [id2.mail],
        # reply_to=['another@example.com'],
        headers={'Message-ID': 'foo'},
        )
        email.send()
        treatment_obj.save()
        C.save()
        print('Saved treatment:', treatment_obj)
        B = tested_patient.objects.get(ssn = patient_id)
        print(B)
        result = tested_patient.objects.all()
        return render(request,'DEO.html',{'data':result})



def weekly_reports(request):

    treatment_ob = treatments.objects.all()
    max_id = physician.objects.aggregate(Max('employeeid'))['employeeid__max']
    arr = [''] * (max_id + 1) 
    for treatment_obj in treatment_ob:
        id1 = patient.objects.get(ssn = treatment_obj.patient_id)
        id2 = physician.objects.get(employeeid = id1.pcp.employeeid)
        app = completed.objects.filter(patientid = id1 , physicianid = id2)
        current_time = timezone.now()
        for completed_obj in app:
            if current_time - completed_obj.endtime < timedelta(days=7):
                s = f"patient_id: {treatment_obj.patient_id} symptoms: {treatment_obj.symptoms} treatments: {treatment_obj.treatments} test_results: {treatment_obj.test_results}"
                arr[id2.employeeid] += s
        
        # k = app.i
        # d = currenttime 
        # diff_in_days = d.days
        # if diff_in_days < 7:
        #     s = 'patient_id : ' + str(treatment_obj.patient_id) + ' ' + 'symptoms :' + treatment_obj.symptoms + ' ' + 'treatments :' + treatment_obj.treatments + ' ' + 'test_results :'+ treatment_obj.test_results
        #     arr[id2.employeeid] =  arr[id2.employeeid] + s
        
    # print(2)
    # print(arr)
    # print(2)
    for i, k in enumerate(arr):
        if k :
            # print('id is ' + str(i) )
            id2 = physician.objects.get(employeeid = i)
            message = 'The user details are: {}'.format(k)
            email = EmailMessage(
            'User details',
            message,
            settings.EMAIL_HOST_USER,
            [id2.mail],
            # reply_to=['another@example.com'],
            headers={'Message-ID': 'foo'},
            )
            email.send()
    results = tested_patient.objects.all()
    return render(request,'DEO.html',{'data':results})


def forgot(request):
    return render(request,'forgot.html')

def change(request):
    if request.method == 'POST':
        global obj
        us = request.POST.get('number')
        try:
            obj = physician.objects.get(employeeid = us)
        except:
            try:
                obj = fdo.objects.get(id = us)
            except:
                try:
                    obj = deo.objects.get(id = us)
                except:
                    print('invalid input id')
        print(id)
        global rand
        rand = random.randint(1, 1000)
        message = 'code: ' + str(rand)
        email = EmailMessage(
            'Change Password',
            message,
            settings.EMAIL_HOST_USER,
            [obj.mail],
            # reply_to=['another@example.com'],
            headers={'Message-ID': 'foo'},
            )
        email.send()

        return render (request,'change_password.html')
    

def change_password(request):
    if request.method == 'POST':
         code = request.POST.get('code')
         code = int(code)
         print(code)
         print(type(code))
         print(rand)
         pasw = request.POST.get('password')
         if code == rand :
            print(1)
            print(obj.password)
            obj.password = pasw
            obj.save()
            return render(request,'Login.html')
         else:
            print('invalid code')
            return render(request,'Login.html')

            


